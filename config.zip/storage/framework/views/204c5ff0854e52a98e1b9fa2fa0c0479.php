<div>
    <h3>Comentarios</h3>
    <!--[if BLOCK]><![endif]--><?php if(session()->has('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <?php if(session()->has('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <!--[if BLOCK]><![endif]--><?php if($comment): ?>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="comment">
                <p class="comment-author"><?php echo e($item->user->name); ?></p>
                <p class="comment-text"><?php echo e($item->content); ?></p>
                <!--[if BLOCK]><![endif]--><?php if(Auth::id() === $item->user_id): ?>
                    <button wire:click="editar(<?php echo e($item->id); ?>)" class="btn btn-warning">Editar</button>
                    <button wire:click="delete(<?php echo e($item->id); ?>)" class="btn btn-danger">Eliminar</button>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <!--[if BLOCK]><![endif]--><?php if(isset($commentsUpdate[$item->id]) && $commentsUpdate[$item->id]): ?>
                <form class="comment-form" wire:submit.prevent='modificar(<?php echo e($item->id); ?>)'>
                    <textarea name="comment" class="comment-input" wire:model='formData.content' placeholder="Escribe tu comentario..."></textarea>
                    <button type="submit" class="comment-submit">Modificar Comentario</button>
                </form>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <button class="btn" wire:click='viewComment'>Nuevo Comentario</button>
    <!--[if BLOCK]><![endif]--><?php if($view): ?>
        <!-- Formulario para agregar comentario -->
        <form class="comment-form" wire:submit.prevent='submit'>
            <textarea name="comment" class="comment-input" wire:model='formData.content' placeholder="Escribe tu comentario..."
                required></textarea>
            <button type="submit" class="comment-submit">Añadir Comentario</button>
        </form>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xamppp\htdocs\Laravel\postify\resources\views/livewire/coments.blade.php ENDPATH**/ ?>