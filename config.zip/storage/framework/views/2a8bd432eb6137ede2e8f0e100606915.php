<div>
    <!--[if BLOCK]><![endif]--><?php if($view): ?>
        <div style="text-align: right">
            <button class="btn btn-danger" wire:click='delete'>Eliminar post</button>
            <button class="btn btn-warning" wire:click='$toggle("update_view")'>Modificar post</button>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($update_view): ?>
        
        
        <form action="<?php echo e(route('pots.update', $this->postId)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="mb-3" style="text-align: center">
                <input style="width: 400px" type="text" name="title" id="title" placeholder="Titulo"
                    value="<?php echo e($post->title); ?>">
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <div class="mb-3">
                <textarea class="form-control" id="content1" name="content1" rows="3" placeholder="Nueva Publicación"
                    resize="none" maxlength="1000" minlength="1" oninput="updateCharCount()"><?php echo e($post->content); ?></textarea>
                <p id="charCount1">1000 Caracteres Restantes</p>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>
            <div class="mb-3">
                <button type="submit" class="btn btn-primary">Actualizar</button>
            </div>
        </form>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

</div>
<?php /**PATH C:\xamppp\htdocs\Laravel\postify\resources\views/livewire/update-and-delete-post.blade.php ENDPATH**/ ?>