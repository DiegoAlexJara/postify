<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Searck</title>

    
    <link rel="stylesheet" href="<?php echo e(asset('css/search.css')); ?>">

</head>

<body>

    <nav class="navbar">
        <div class="container">
            <!-- Enlace con imagen para regresar -->
            <a href="<?php echo e(route('Inicio')); ?>" class="dropdown-item">
                <img src="<?php echo e(asset('img/return.png')); ?>" alt="Regresar" class="return-icon">
            </a>

            <!-- Formulario de búsqueda de usuario -->
            <form action="<?php echo e(route('BuscarUser')); ?>" method="GET" class="search-form">
                <input type="text" name="query" id="query" placeholder="Usuario" class="input-text" required>
                <input type="submit" value="Buscar" class="submit-btn">
            </form>
        </div>
    </nav>
    <div class="results-container">
        <?php if(isset($users) && $users->count()): ?>
            <h2>Resultados para: "<?php echo e($query); ?>"</h2>
            <div class="user-cards">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="user-card">
                    <h3><?php echo e($user->name); ?></h3>
                    <p>Email: <?php echo e($user->email); ?></p>
                    <p>Registrado el: <?php echo e($user->created_at->format('d-m-Y')); ?></p>
                    <a href="<?php echo e(route('visit', $user->name)); ?>" class="view-button">Ver Usuario</a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <h2>No se encontraron resultados para: "<?php echo e($query); ?>"</h2>
        <?php endif; ?>
    </div>
</body>

</html>
<?php /**PATH C:\xamppp\htdocs\Laravel\postify\resources\views/User/search.blade.php ENDPATH**/ ?>