<div class="container">
    <div class="mb-3">
        
        <button class="btn btn-light" style="display: block; margin: 0 auto;" wire:click='viewCreate'>CREAR
            PUBLICACION</button>
    </div>

    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('message')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->


    <!--[if BLOCK]><![endif]--><?php if($view): ?>
        <div class="form-post">
            <form wire:submit.prevent="submit">
                <div class="mb-3">
                    <input type="text" wire:model="formData.title" id="title" placeholder="Titulo">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['formData.title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
                <div class="mb-3">
                    <textarea class="form-control" id="content" wire:model="formData.content" rows="3"
                        placeholder="Nueva Publicación" resize="none" maxlength="1000" minlength="1" oninput="updateCharCount()"></textarea>
                    <p id="charCount">1000 Caracteres Restantes</p>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['formData.content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
                <div class="mb-3">
                    <button type="submit" class="btn btn-primary">CREAR</button>
                </div>
            </form>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registros): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="post">
            <h2 class="post-title"><?php echo e($registros->title); ?></h2>
            <p class="post-author">Escrito por <strong><?php echo e($registros->user->name); ?></strong></p>
            <p class="post-content"><?php echo e($registros->content); ?></p>
            

            <!--[if BLOCK]><![endif]--><?php if(Auth::user()->name === $registros->user->name): ?>
                <div style="text-align: right">
                    <button class="btn btn-danger" wire:click='delete(<?php echo e($registros->id); ?>)'>Eliminar post</button>
                    <button class="btn btn-warning" wire:click='toggleUpdate(<?php echo e($registros->id); ?>)'>Modificar
                        post</button>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <!--[if BLOCK]><![endif]--><?php if(isset($update[$registros->id]) && $update[$registros->id]): ?>
                <div class="form-post">
                    <form wire:submit.prevent="ActualizarPost(<?php echo e($registros->id); ?>)">
                        <div class="mb-3">
                            <input type="text" wire:model="formData.title" id="title" placeholder="Titulo">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['formData.title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="mb-3">
                            <textarea class="form-control" id="content" wire:model="formData.content" rows="3"
                                placeholder="Nueva Publicación" resize="none" maxlength="1000" minlength="1" oninput="updateCharCount()"></textarea>
                            <p id="charCount">1000 Caracteres Restantes</p>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['formData.content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="mb-3">
                            <button type="submit" class="btn btn-primary">ACTUALIZAR</button>
                        </div>
                    </form>

                    </form>
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!-- Sección de comentarios -->
            <div class="comments">

                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('Coments', ['postId'=> $registros->id]);

$__html = app('livewire')->mount($__name, $__params, $registros->id, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->


    <script>
        function testEvent(text) {
            Livewire.dispatch('test-event', text);
        }
    </script>


</div>
<?php /**PATH C:\xamppp\htdocs\Laravel\postify\resources\views/livewire/new-post.blade.php ENDPATH**/ ?>